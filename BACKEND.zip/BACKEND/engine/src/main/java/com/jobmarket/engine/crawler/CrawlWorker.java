package com.jobmarket.engine.crawler;

import com.jobmarket.engine.crawler.attempt.CrawlAttempt;
import com.jobmarket.engine.crawler.attempt.CrawlAttemptRepository;
import com.jobmarket.engine.crawler.attempt.CrawlStatus;
import com.jobmarket.engine.crawler.target.CrawlTarget;
import com.jobmarket.engine.domain.job.Job;
import com.jobmarket.engine.evidence.source.SourceSite;
import com.jobmarket.engine.service.resolver.JobResolverService;
import com.jobmarket.engine.service.resolver.ObservationRecorderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class CrawlWorker {

    private final CrawlAttemptRepository crawlAttemptRepository;
    private final JobResolverService jobResolverService;
    private final ObservationRecorderService observationRecorderService;

    // Honest user agent — we identify ourselves clearly
    // Memory rule: no deceptive crawling
    private static final String USER_AGENT =
            "JobMarketObserver/1.0 (Research crawler; observes public job listings)";

    private static final int TIMEOUT_MS = 10_000;

    /**
     * Processes one CrawlTarget completely:
     *   1. Creates CrawlAttempt record (we ALWAYS record what we tried)
     *   2. Fetches HTML with JSoup — retries up to max_retries
     *   3. Parses job cards from HTML
     *   4. For each card → resolve job → record observation
     *   5. Completes CrawlAttempt with final status + count
     *
     * KEY MEMORY RULE:
     * If fetch fails → record HTTP_FAIL → STOP. Do NOT touch any job data.
     * Missing observation after HTTP_FAIL ≠ job disappeared.
     */
    public void process(CrawlTarget target) {
        SourceSite site = target.getSourceSite();
        log.info("Starting crawl: site='{}', url='{}'", site.getName(), target.getUrl());

        // Create attempt record — BEFORE we try anything
        // We record the attempt regardless of outcome
        CrawlAttempt attempt = CrawlAttempt.builder()
                .crawlTarget(target)
                .startedAt(LocalDateTime.now())
                .status(CrawlStatus.HTTP_FAIL)   // pessimistic default
                .jobsFoundCount(0)
                .build();
        attempt = crawlAttemptRepository.save(attempt);

        // Fetch with retry logic
        Document document = fetchWithRetry(target, site, attempt);
        if (document == null) return; // HTTP_FAIL already recorded inside fetchWithRetry

        // Parse job cards from fetched HTML
        List<ParsedJobData> parsedJobs;
        try {
            parsedJobs = parseJobCards(document, target.getUrl());
        } catch (Exception e) {
            // Page loaded but parser broke
            // PARSE_FAIL is different from HTTP_FAIL:
            //   HTTP_FAIL  → couldn't reach site
            //   PARSE_FAIL → site changed HTML structure, our selectors broke
            log.error("Parse failed for URL: {} — {}", target.getUrl(), e.getMessage());
            attempt.complete(CrawlStatus.PARSE_FAIL, 200, "Parser error: " + e.getMessage(), 0);
            crawlAttemptRepository.save(attempt);
            return;
        }

        log.info("Parsed {} job cards from: {}", parsedJobs.size(), target.getUrl());

        // Run each card through the full pipeline
        int successCount = 0;
        for (ParsedJobData jobData : parsedJobs) {
            try {
                // Dedup — find existing or create new logical job
                Job job = jobResolverService.resolve(
                        jobData.getRawCompany(),
                        jobData.getRawTitle(),
                        jobData.getRawLocation()
                );

                // Record evidence — append observation row
                observationRecorderService.record(
                        job,
                        site,
                        attempt,
                        jobData.getListingUrl(),
                        jobData.getRawTitle(),
                        jobData.getSalaryText()
                );

                successCount++;
                sleep(site.getCrawlDelaySeconds() * 200L); // polite delay between cards

            } catch (Exception e) {
                // One bad card doesn't stop the rest
                log.error("Failed processing card: '{}' — {}", jobData.getRawTitle(), e.getMessage());
            }
        }

        // Mark attempt complete
        attempt.complete(CrawlStatus.SUCCESS, 200, null, successCount);
        crawlAttemptRepository.save(attempt);
        log.info("Crawl complete: site='{}', recorded={}/{}", site.getName(), successCount, parsedJobs.size());
    }

    /**
     * Fetches page with exponential backoff retry.
     *
     * Backoff schedule (per memory rule — max_retries from source_site):
     *   Attempt 1 fails → wait 2s
     *   Attempt 2 fails → wait 4s
     *   Attempt 3 fails → wait 8s
     *   All exhausted → record HTTP_FAIL, return null
     *
     * Returns null if all retries fail — caller handles it.
     */
    private Document fetchWithRetry(CrawlTarget target, SourceSite site, CrawlAttempt attempt) {
        int maxRetries = site.getMaxRetries();

        for (int i = 0; i <= maxRetries; i++) {
            try {
                sleep(site.getCrawlDelaySeconds() * 1000L); // polite delay before each fetch
                Document doc = Jsoup.connect(target.getUrl())
                        .userAgent(USER_AGENT)
                        .timeout(TIMEOUT_MS)
                        .followRedirects(true)
                        .get();
                log.debug("Fetch success on attempt {}", i + 1);
                return doc;

            } catch (IOException e) {
                log.warn("Fetch failed (attempt {}/{}): {}", i + 1, maxRetries + 1, e.getMessage());
                if (i < maxRetries) {
                    long backoffMs = (long) Math.pow(2, i + 1) * 1000;
                    log.debug("Backing off for {}ms", backoffMs);
                    sleep(backoffMs);
                }
            }
        }

        // All retries exhausted
        log.error("All {} attempts failed for: {}", maxRetries + 1, target.getUrl());
        attempt.complete(CrawlStatus.HTTP_FAIL, null,
                "All " + (maxRetries + 1) + " attempts failed", 0);
        crawlAttemptRepository.save(attempt);
        return null;
        // Returning null here — no job data touched. Memory rule 6 preserved.
    }

    /**
     * Parses job cards from HTML document for Freshersworld.
     */
    private List<ParsedJobData> parseJobCards(Document document, String baseUrl) {
        List<ParsedJobData> results = new ArrayList<>();

        // Freshersworld real job card container
        Elements jobCards = document.select(".job-container");

        log.info("Found {} job cards", jobCards.size());

        if (jobCards.isEmpty()) {
            log.error("ZERO job cards detected — selector likely broken or page blocked");
            throw new RuntimeException("Parser found 0 job cards");
        }

        for (Element card : jobCards) {
            try {

                // Title
                String title = extractText(card, "h3.latest-jobs-title a");

                // Company
                String company = extractText(card, ".company-name");

                // Location (site inconsistent — fallback handled)
                String location = extractText(card,
                        ".job-location, .location, .jobs-location");

                if (location.isBlank()) location = "India";

                // Stable URL from attribute (do NOT build from <a>)
                String url = card.attr("job_display_url");

                if (title.isBlank() || company.isBlank() || url.isBlank()) {
                    log.debug("Skipping invalid card");
                    continue;
                }

                results.add(ParsedJobData.builder()
                        .rawTitle(title)
                        .rawCompany(company)
                        .rawLocation(location)
                        .listingUrl(url)
                        .salaryText(null)
                        .build());

                log.debug("Parsed: {} | {} | {}", title, company, location);

            } catch (Exception e) {
                log.debug("Skipping bad card: {}", e.getMessage());
            }
        }

        return results;
    }

    private String extractText(Element parent, String cssSelector) {
        Element el = parent.selectFirst(cssSelector);
        return el != null ? el.text().trim() : "";
    }

    private void sleep(long ms) {
        if (ms <= 0) return;
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
