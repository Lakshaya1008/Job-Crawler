package com.jobmarket.engine;

import com.jobmarket.engine.crawler.target.CrawlTarget;
import com.jobmarket.engine.crawler.target.CrawlTargetRepository;
import com.jobmarket.engine.evidence.source.SourceSite;
import com.jobmarket.engine.evidence.source.SourceSiteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Seeds minimum required data on first startup.
 *
 * CommandLineRunner runs ONCE after Spring Boot fully starts.
 * We check if data already exists before inserting — idempotent.
 * Safe to run every startup — won't duplicate data.
 *
 * WHY seed in code, not SQL?
 * Because SourceSite has business config (thresholds, weights) that
 * belongs close to the code that uses it. Easier to read and modify.
 *
 * For V1: seeding Internshala as the first crawl target.
 * Internshala serves static HTML → works with JSoup → good starting point.
 * LinkedIn/Naukri have anti-bot measures → tackle later.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final SourceSiteRepository sourceSiteRepository;
    private final CrawlTargetRepository crawlTargetRepository;

    @Override
    public void run(String... args) {
        seedInternshala();
        log.info("DataSeeder complete — system ready to crawl");
    }

    private void seedInternshala() {
        // Idempotent: skip if already exists
        if (sourceSiteRepository.findByName("internshala").isPresent()) {
            log.debug("Internshala already seeded — skipping");
            return;
        }

        log.info("Seeding Internshala source site...");

        SourceSite internshala = SourceSite.builder()
                .name("internshala")
                .inactiveThresholdDays(5)       // listings usually close within 5 days
                .repostThresholdDays(21)         // if same job reappears after 3 weeks → new cycle
                .reliabilityWeight(0.75)         // reasonable trust level
                .crawlDelaySeconds(3)            // 3 seconds between requests — polite
                .maxRetries(2)                   // retry twice before giving up
                .crawlEnabled(true)
                .build();

        internshala = sourceSiteRepository.save(internshala);
        log.info("Internshala source site created with id={}", internshala.getId());

        // Seed one crawl target — backend jobs on Internshala
        // When you start crawling, inspect this page's HTML and update
        // parseJobCards() selectors in CrawlWorker to match its structure
        String targetUrl = "https://www.freshersworld.com/jobs/jobsearch/java-developer-jobs-for-freshers";
        CrawlTarget target = CrawlTarget.builder()
                .sourceSite(internshala)
                .url(targetUrl)
                .active(true)
                .build();

        crawlTargetRepository.save(target);
        log.info("Crawl target seeded: {}", target.getUrl());
    }
}
