-- V1 schema managed by Hibernate DDL auto
-- Flyway tracks versions from here forward
-- Tables already created by Hibernate on first run
SELECT 1;